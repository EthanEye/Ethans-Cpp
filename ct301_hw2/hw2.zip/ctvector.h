#ifndef CT_VECTOR_H
#define CT_VECTOR_H

// ============================================================================
// CT 301 - HW#2 (Summer 2026) - ctvector.h  [STUDENT STARTER]
// ----------------------------------------------------------------------------
// You implement every body marked  // TODO . Do NOT change any signature.
// All includes and all type aliases are given. A set of functions is written
// for you as worked examples; the rest are signatures with a one-line hint.
//
//   The aliases below use "using NAME = TYPE;". You may see the older spelling
//   "typedef TYPE NAME;" in other code; they mean the same thing (see the
//   assignment document for why both exist).
//
// Standard: C++26.  Build: -std=c++26 -Wall -Wextra -Wpedantic
//                          -fsanitize=address,undefined -g
// You may NOT use std::vector or smart pointers. Manage storage with raw
// pointers. Every element you construct must be destroyed exactly once.
//
// ----------------------------------------------------------------------------
//  WARNING: every // TODO body below is a NON-FUNCTIONAL PLACEHOLDER, and the
//  worked examples call into them. The file builds and runs from day one (each
//  constructor delegates to Vector() so the object is a valid EMPTY vector),
//  but until you replace a TODO that operation does the WRONG thing. The given
//  insert/emplace/push_back will not work until the helpers they call
//  (push_back, emplace_back, grow_if_needed, begin/end, ...) are implemented.
//  Do not trust any result until its TODO is done.
// ============================================================================

#include <algorithm>        // std::rotate, std::equal, std::move
#include <cstddef>          // std::size_t, std::ptrdiff_t
#include <initializer_list> // std::initializer_list
#include <iterator>         // std::reverse_iterator
#include <limits>           // std::numeric_limits
#include <memory>           // std::uninitialized_*, std::destroy_*
#include <stdexcept>        // std::out_of_range, std::length_error, std::logic_error
#include <utility>          // std::move, std::forward

// Warning suppressor: lets the stubs keep readable, named parameters before
// they are used. Delete this once everything is implemented.
#pragma GCC diagnostic push
#pragma GCC diagnostic ignored "-Wunused-parameter"

namespace ct
{

  template <typename T>
  class Vector
  {
  public:
    // ---- Member type aliases (given) --------------------------------------
    using value_type =
        T;                         // the type of element stored in the container (whatever T is).
    using size_type = std::size_t; // an unsigned integer type used for sizes and
                                   // counts (like how many elements you have).
    using difference_type =
        std::ptrdiff_t;  // a signed integer type used for the distance between two
                         // iterators/pointers.
    using pointer = T *; // a raw pointer to a mutable element (T*).
    using const_pointer =
        const T *; // a raw pointer to a read-only element (const T*).
    using reference =
        T &;                           // a reference to a mutable element, so you can modify it in place.
    using const_reference = const T &; // a reference to a read-only element, used
                                       // for safe access without copying.
    using iterator = T *;              // a raw pointer that lets you traverse and modify
                                       // elements (works because the data is contiguous).
    using const_iterator =
        const T *; // same traversal but you can't modify what it points to.
    using reverse_iterator =
        std::reverse_iterator<iterator>; //  wraps iterator so you can walk
                                         //  backward through the container.
    using const_reverse_iterator =
        std::reverse_iterator<const_iterator>; // same backward traversal but
                                               // read-only.

    // ---- Constructors / destructor ----------------------------------------
    Vector() noexcept : elements_(nullptr), size_(0), capacity_(0) {} // given

    explicit Vector(size_type count) : Vector()
    { // given
      if (count > 0)
      {
        reserve(count);
        std::uninitialized_value_construct_n(elements_, count);
        size_ = count;
      }
    }

    Vector(size_type count, const T &value) : Vector()
    {
      // TODO: make room for count, then copy-construct that many values.
      if (count > 0)
      {
        reserve(count); // allocates memory initializes elements_ member to that
                        // address
        for (size_type i = 0; i < count; i++)
        {
          new (elements_ + i) T(value); // placement new copy value into each slot
        }
        size_ = count;
      }
    }
    // a initializer list uses curly brackets { }
    Vector(std::initializer_list<T> list) : Vector()
    {
      // TODO: make room for list.size(), then copy the elements in.
      reserve(list.size());
      for (const T &val : list)
      {
        new (elements_ + size_) T(val);
        size_++;
      }
    }

    // Range constructor from a pointer range. A const_iterator (pointer) cannot
    // be confused with an integer count, so no template and no concepts.
    Vector(const_iterator first, const_iterator last) : Vector()
    {
      size_type range = static_cast<size_type>(last - first);
      if (range > 0)
      {
        reserve(range);
        for (size_type i = 0; i < range; i++)
        {
          new (elements_ + i) T(first[i]);
        }
        size_ = range;
      }
    }

    Vector(const Vector &other) : Vector()
    {
      // TODO: make room for other.size(), then copy its elements in.
      size_type new_size = other.size_;
      if (new_size > 0)
      {
        reserve(new_size);
        for (size_type i = 0; i < new_size; i++)
        {
          new (elements_ + i) T(other.elements_[i]);
        }
      }
      size_ = new_size;
    }

    Vector(Vector &&other) noexcept : Vector()
    {
      // TODO: steal other's buffer/size/capacity; leave other empty.
      elements_ = other.elements_;
      size_ = other.size_;
      capacity_ = other.capacity_;

      other.elements_ = nullptr;
      other.size_ = 0;
      other.capacity_ = 0;
    }

    ~Vector()
    { // given
      clear();
      deallocate();
    }

    // ---- Assignment -------------------------------------------------------
    Vector &operator=(const Vector &other)
    {
      // TODO: copy-assign (copy-and-swap is one clean way).
      Vector temp(other); // make a copy using copy constructor
      swap(temp);         // swap temp with the copys guts
      return *this;
    }

    Vector &operator=(Vector &&other) noexcept
    {
      // TODO: release what you hold, then steal from other.
      clear();                      // destroy current elements
      ::operator delete(elements_); // free current buffer

      elements_ = other.elements_; // steal their pointer
      size_ = other.size_;
      capacity_ = other.capacity_;

      other.elements_ =
          nullptr; // leave other in a valid empty state so it can delete this
                   // memory when its destructor is called
      other.size_ = 0;
      other.capacity_ = 0;

      return *this;
    }

    Vector &operator=(std::initializer_list<T> list)
    { // given
      assign(list);
      return *this;
    }

    // ---- assign -----------------------------------------------------------
    void assign(const_iterator first, const_iterator last)
    {
      // TODO: drop current contents, then take the elements of [first,last).
      size_type n = std::distance(first, last);
      clear();
      ::operator delete(elements_);
      elements_ = allocate(n); // make sure to allocate new buffer
      for (size_type i = 0; i < n; i++)
      {
        new (&elements_[i]) T(first[i]);
      }

      size_ = n;
      capacity_ = n;
    }

    void assign(size_type count, const T &value)
    {
      // TODO: drop current contents, then hold count copies of value.
      clear();
      ::operator delete(elements_);
      elements_ = allocate(count);
      for (size_type i = 0; i < count; i++)
      {
        new (&elements_[i]) T(value);
      }
      size_ = count;
      capacity_ = count;
    }

    void assign(std::initializer_list<T> ilist)
    { // given (delegates)
      assign(ilist.begin(), ilist.end());
    }

    // ---- Element access ---------------------------------------------------
    // back() is given as the worked example. Mirror it for at/[]/front/data.
    T &at(size_type pos)
    {
      if (pos >= size_)
        throw std::out_of_range("ct::Vector::at: out of range");
      return elements_[pos];
    }
    const T &at(size_type pos) const
    {
      if (pos >= size_)
        throw std::out_of_range("ct::Vector::at: out of range");
      return elements_[pos];
    }
    // [] dosent bounds check because its ment to be fast.
    T &operator[](size_type pos) { return elements_[pos]; }
    const T &operator[](size_type pos) const { return elements_[pos]; }
    T &front()
    {
      if (empty())
        throw std::out_of_range("ct::Vector::front: empty");
      return elements_[0];
    }
    const T &front() const
    {
      if (empty())
        throw std::out_of_range("ct::Vector::front: empty");
      return elements_[0];
    }

    T &back()
    { // given
      if (empty())
        throw std::out_of_range("ct::Vector::back: empty");
      return elements_[size_ - 1];
    }
    const T &back() const
    { // given
      if (empty())
        throw std::out_of_range("ct::Vector::back: empty");
      return elements_[size_ - 1];
    }

    T *data() noexcept
    {
      return elements_;
    }
    const T *data() const noexcept
    {
      return elements_;
    }

    // ---- Forward iterators ------------------------------------------------
    iterator begin() noexcept { return elements_; }
    const_iterator begin() const noexcept { return elements_; /* TODO */ }
    iterator end() noexcept { return elements_ + size_; }
    const_iterator end() const noexcept { return elements_ + size_; /* TODO */ }
    const_iterator cbegin() const noexcept { return elements_; /* TODO */ }
    const_iterator cend() const noexcept { return elements_ + size_; } // given

    // ---- Reverse iterators ------------------------------------------------
    // rbegin() is given. Mirror it: rend maps to begin(), and the const/c-
    // versions follow the same shape (use std::reverse_iterator).
    reverse_iterator rbegin() noexcept
    {
      return reverse_iterator(end());
    } // given
    const_reverse_iterator rbegin() const noexcept
    {
      return const_reverse_iterator(end());
    }
    reverse_iterator rend() noexcept { return reverse_iterator(begin()); }
    const_reverse_iterator rend() const noexcept
    {
      return const_reverse_iterator(begin());
    }
    const_reverse_iterator crbegin() const noexcept
    {
      return const_reverse_iterator(cend());
    }
    const_reverse_iterator crend() const noexcept
    {
      return const_reverse_iterator(cbegin());
    }

    // ---- Capacity ---------------------------------------------------------
    bool empty() const noexcept { return size_ == 0; /* TODO */ }
    size_type size() const noexcept { return size_; /* TODO */ }
    size_type capacity() const noexcept { return capacity_; /* TODO */ }
    size_type max_size() const noexcept
    { // given
      return std::numeric_limits<size_type>::max() / sizeof(T);
    }

    // The heart of the assignment. Grow the buffer to hold at least new_cap.
    //   1. allocate raw storage (allocate()).   3. destroy the old elements.
    //   2. move your live elements into it.      4. free the old buffer; adopt
    //   new.
    // Do nothing if new_cap <= capacity_.
    void reserve(size_type new_cap)
    {
      if (new_cap > max_size())
        throw std::length_error("ct::Vector::reserve: exceeds max_size");
      if (new_cap <= capacity_)
        return;

      T *new_data = allocate(new_cap);

      if (elements_ != nullptr)
      { // only move/destroy if theres something there
        std::uninitialized_move_n(elements_, size_, new_data);
        std::destroy_n(elements_, size_);
        deallocate();
      }

      elements_ = new_data;
      capacity_ = new_cap;
    }

    void shrink_to_fit()
    {
      if (capacity_ == size_)
        return;

      if (size_ == 0)
      {
        deallocate();
        elements_ = nullptr;
        capacity_ = 0;
        return;
      }

      T *new_data = allocate(size_);
      std::uninitialized_move_n(elements_, size_, new_data);
      std::destroy_n(elements_, size_);
      deallocate();
      elements_ = new_data;
      capacity_ = size_;
    }

    // ---- Modifiers --------------------------------------------------------
    void clear() noexcept
    {
      // TODO: destroy every element; size becomes 0 (capacity unchanged).
      if (size_ > 0)
      {

        for (size_type i = 0; i < size_; i++)
        {
          elements_[i].~T();
        }
      }
      size_ = 0;
    }

    iterator insert(const_iterator pos, const T &value)
    { // given
      const size_type index = static_cast<size_type>(pos - begin());
      push_back(value);
      std::rotate(begin() + index, end() - 1, end());
      return begin() + index;
    }

    iterator insert(const_iterator pos, T &&value)
    {
      // TODO: like the given insert, but move the value in.
      const size_type index = static_cast<size_type>(pos - begin());
      push_back(std::move(value));
      std::rotate(begin() + index, end() - 1, end());
      return begin() + index;
    }

    iterator insert(const_iterator pos, size_type count, const T &value)
    {
      const size_type index = static_cast<size_type>(pos - begin());
      for (size_type i = 0; i < count; i++)
        push_back(value);
      std::rotate(begin() + index, end() - count, end());
      return begin() + index;
    }

    iterator insert(const_iterator pos, const_iterator first, const_iterator last)
    {

      const size_type index = static_cast<size_type>(pos - begin());
      size_type count = static_cast<size_type>(last - first);
      for (const_iterator it = first; it != last; ++it)
        push_back(*it);
      std::rotate(begin() + index, end() - count, end());
      return begin() + index;
    }

    iterator insert(const_iterator pos,
                    std::initializer_list<T> il)
    { // given (delegates)
      return insert(pos, il.begin(), il.end());
    }

    template <typename... Args>
    iterator emplace(const_iterator pos, Args &&...args)
    { // given
      const size_type index = static_cast<size_type>(pos - begin());
      emplace_back(std::forward<Args>(args)...);
      std::rotate(begin() + index, end() - 1, end());
      return begin() + index;
    }

    iterator erase(const_iterator pos)
    {
      const size_type index = static_cast<size_type>(pos - begin());
      std::rotate(begin() + index, begin() + index + 1, end());
      std::destroy_at(elements_ + size_ - 1);
      --size_;
      return begin() + index;
    }

    iterator erase(const_iterator first, const_iterator last)
    {
      // TODO: remove [first, last); return iterator to the element after.
      const size_type index = static_cast<size_type>(first - begin());
      const size_type count = static_cast<size_type>(last - first);
      std::rotate(begin() + index, begin() + index + count, end());
      std::destroy_n(elements_ + size_ - count, count);
      size_ -= count;
      return begin() + index;
    }

    void push_back(const T &value)
    {
      // TODO: if full, grow; then construct a copy of value at the end.
      grow_if_needed(1);
      new (elements_ + size_) T(value);
      ++size_;
    }

    void push_back(T &&value)
    { // given
      grow_if_needed(1);
      new (elements_ + size_) T(std::move(value));
      ++size_;
    }
    // packs get a bunch of values and creates an object with those values.
    template <typename... Args>
    void emplace_back(Args &&...args)
    {
      // TODO: if full, grow; then construct from args at the end.
      grow_if_needed(1);
      new (elements_ + size_) T(std::forward<Args>(args)...);
      ++size_;
    }

    void pop_back()
    {
      // TODO: destroy the last element; size shrinks by one.
      if (size_ >= 1)
      {
        std::destroy_at(elements_ + size_ - 1); // call destructor on last element
        size_--;
      }
    }

    void resize(size_type count)
    {
      // TODO: shrink (destroy tail) or grow (value-initialize new tail).
      if (count < size_)
      {
        // shrink destroy elements from count to size_
        std::destroy_n(elements_ + count, size_ - count);
        size_ = count;
      }
      else if (count > size_)
      {
        // grow value-initialize new slots
        if (count > capacity_)
          reserve(count);
        std::uninitialized_value_construct_n(elements_ + size_, count - size_);
        size_ = count;
      }
    }

    void resize(size_type count, const T &value)
    {
      if (count < size_)
      {
        // shrink — same as before
        std::destroy_n(elements_ + count, size_ - count);
        size_ = count;
      }
      else if (count > size_)
      {
        if (count > capacity_)
          reserve(count);
        // fill new slots with value instead of zero-initializing
        std::uninitialized_fill_n(elements_ + size_, count - size_, value);
        size_ = count;
      }
    }

    void swap(Vector &other) noexcept
    {
      // TODO: swap the buffer pointer, size, and capacity with other.
      std::swap(elements_, other.elements_);
      std::swap(size_, other.size_);
      std::swap(capacity_, other.capacity_);
    }

  private:
    T *elements_;
    size_type size_;
    size_type capacity_;

    static constexpr size_type initSize = 8;  // suggested first capacity
    static constexpr size_type incFactor = 2; // suggested 2x growth

    // TODO: growth policy. If size_ + extra would not fit, grow capacity_
    // (double it, or start at initSize) by calling reserve().
    void grow_if_needed(size_type extra)
    {
      // TODO
      if (size_ + extra <= capacity_)
        return; // enough room, do nothing

      size_type new_cap = capacity_ == 0 ? initSize : capacity_ * incFactor;

      while (new_cap < size_ + extra) // in case extra > 1
        new_cap *= incFactor;
      reserve(new_cap);
    }

    // TODO: raw storage helpers (the memory is yours to manage).
    //   allocate(n):  uninitialized space for n objects, NO constructors run.
    //                 The raw call is  ::operator new(sizeof(T) * n)  cast to T*.
    //   deallocate(): free the buffer with  ::operator delete(elements_) .
    T *allocate(size_type n)
    {
      // TODO
      void *raw =
          ::operator new(sizeof(T) * n); // stores pointer first no type yet
      T *ptr = static_cast<T *>(raw);    // determine the type needed

      return ptr;
    }
    void deallocate() noexcept
    {
      ::operator delete(elements_);
      elements_ = nullptr;
      capacity_ = 0;
    }
  };

  // ---- Non-member functions ------------------------------------------------
  template <typename T>
  bool operator==(const Vector<T> &lhs, const Vector<T> &rhs)
  {
    if (lhs.size() != rhs.size())
      return false;
    return std::equal(lhs.begin(), lhs.end(), rhs.begin());
  }

  template <typename T> // given (delegates)
  bool operator!=(const Vector<T> &lhs, const Vector<T> &rhs)
  {
    return !(lhs == rhs);
  }

  // Given. This non-member swap forwards to the MEMBER swap you write:
  // it calls lhs.swap(rhs); your member swap exchanges elements_, size_, and
  // capacity_ (use std::swap on each member).
  template <typename T> // given (delegates)
  void swap(Vector<T> &lhs, Vector<T> &rhs) noexcept
  {
    lhs.swap(rhs);
  }

} // namespace ct

#pragma GCC diagnostic pop

#endif // CT_VECTOR_H
